#!/bin/bash
# ─────────────────────────────────────────────
#  MindSync — One-Command Deploy to Vercel
#  Run this file: bash DEPLOY.sh
# ─────────────────────────────────────────────

echo ""
echo "🧠 MindSync Deploy Script"
echo "─────────────────────────"
echo ""

# Check Node
if ! command -v node &> /dev/null; then
  echo "❌ Node.js not found. Install from https://nodejs.org"
  exit 1
fi

echo "✅ Node.js $(node -v) found"

# Install deps
echo ""
echo "📦 Installing dependencies..."
npm install

# Check for .env
if [ ! -f ".env" ]; then
  cp .env.example .env
  echo ""
  echo "⚠️  Created .env from .env.example"
  echo "   Please add your Supabase + Anthropic keys to .env before deploying"
  echo "   Then run this script again."
  echo ""
  exit 0
fi

# Install Vercel CLI if needed
if ! command -v vercel &> /dev/null; then
  echo ""
  echo "📡 Installing Vercel CLI..."
  npm install -g vercel
fi

echo ""
echo "🚀 Deploying to Vercel..."
echo ""
vercel --prod

echo ""
echo "✅ Done! Your MindSync app is live 💜"
echo ""
