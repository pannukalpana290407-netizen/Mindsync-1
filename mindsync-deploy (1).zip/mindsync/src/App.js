import React from "react";
import { useState, useEffect, useRef, useCallback } from "react";

// ── Palette & helpers ────────────────────────────────────────────────────────
const IS_NIGHT = () => {
  const h = new Date().getHours();
  return h >= 22 || h < 6;
};

// ── Mock Supabase layer (replace with real supabase-js) ──────────────────────
const mockUser = null;
const supabase = {
  auth: {
    getSession: async () => ({ data: { session: null } }),
    signInWithOAuth: async ({ provider }) => {
      alert(`[Demo] Google OAuth would open here.\nProvider: ${provider}`);
      return { error: null };
    },
    signInWithPassword: async ({ email, password }) => {
      if (email && password) {
        return {
          data: {
            user: {
              id: "demo-uid",
              email,
              user_metadata: { full_name: email.split("@")[0], avatar_url: null },
            },
          },
          error: null,
        };
      }
      return { data: null, error: { message: "Invalid credentials" } };
    },
    signUp: async ({ email, password }) => {
      return {
        data: {
          user: {
            id: "demo-uid",
            email,
            user_metadata: { full_name: email.split("@")[0], avatar_url: null },
          },
        },
        error: null,
      };
    },
    signOut: async () => ({ error: null }),
    onAuthStateChange: (cb) => {
      return { data: { subscription: { unsubscribe: () => {} } } };
    },
  },
};

// ── Anthropic AI call ────────────────────────────────────────────────────────
async function callAI(messages, system) {
  const res = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      model: "claude-sonnet-4-20250514",
      max_tokens: 1000,
      system,
      messages,
    }),
  });
  const data = await res.json();
  return data.content?.map((b) => b.text || "").join("") || "I'm here with you ❤️";
}

const COMPANION_SYSTEM = `You are MindSync Companion, a warm, gentle, and highly empathetic AI mental wellness friend. Your only purpose is to make users feel safe, understood, and supported — especially when they are struggling with anxiety or panic attacks.

SAFETY RULES:
1. If the user mentions bleeding, heavy bleeding, injury, or self-harm, immediately say: "I'm really worried about you right now. Please check if the bleeding is heavy or won't stop. If it is, go to the nearest hospital or call emergency services right now. I'm here with you, but this needs real medical help."
2. For panic attacks or severe anxiety, always offer immediate calming steps first.
3. If symptoms sound dangerous (chest pain, fainting, uncontrollable bleeding, suicidal thoughts), gently but firmly suggest calling emergency services or talking to a real therapist.

Response Structure (Always follow):
1. Acknowledge their feeling with empathy (1 line)
2. Quick validation
3. Immediate helpful action (breathing / grounding)
4. Short explanation if they asked
5. Offer next step: breathing exercise, mood tracker, or therapist session
6. End with: "I'm right here with you ❤️"

Tone: Speak like a caring friend. Simple words, short sentences, warm tone. Always stay calm and hopeful. Never diagnose.`;

// ── Icons (inline SVG components) ────────────────────────────────────────────
const Icon = ({ d, size = 20, className = "" }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <path d={d} />
  </svg>
);

const icons = {
  moon: "M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z",
  sun: "M12 1v2M12 21v2M4.22 4.22l1.42 1.42M18.36 18.36l1.42 1.42M1 12h2M21 12h2M4.22 19.78l1.42-1.42M18.36 5.64l1.42-1.42M12 5a7 7 0 1 0 0 14A7 7 0 0 0 12 5z",
  chat: "M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z",
  heart: "M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z",
  chart: "M18 20V10M12 20V4M6 20v-6",
  brain: "M9.5 2A2.5 2.5 0 0 1 12 4.5v15a2.5 2.5 0 0 1-4.96-.46 2.5 2.5 0 0 1-1.07-4.53A3 3 0 0 1 4.5 9.5a3 3 0 0 1 2.5-2.96V6.5A2.5 2.5 0 0 1 9.5 2z",
  user: "M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2M12 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8z",
  toolkit: "M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z",
  doctor: "M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2zM9 22V12h6v10",
  star: "M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z",
  logout: "M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4M16 17l5-5-5-5M21 12H9",
  mic: "M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3zM19 10v2a7 7 0 0 1-14 0v-2M12 19v4M8 23h8",
  send: "M22 2L11 13M22 2L15 22 11 13 2 9l20-7z",
  close: "M18 6L6 18M6 6l12 12",
  check: "M20 6L9 17l-5-5",
  plus: "M12 5v14M5 12h14",
  calendar: "M3 4h18v18H3zM16 2v4M8 2v4M3 10h18",
  video: "M23 7l-7 5 7 5V7zM1 5h15a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H1a2 2 0 0 1-2-2V7a2 2 0 0 1 2-2z",
};

// ── CSS ───────────────────────────────────────────────────────────────────────
const CSS = `
@import url('https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;600;700&family=DM+Sans:wght@300;400;500;600&display=swap');

:root {
  --bg: #f0eef9;
  --bg2: #e8e5f5;
  --surface: rgba(255,255,255,0.8);
  --surface2: rgba(255,255,255,0.6);
  --border: rgba(150,130,200,0.2);
  --text: #2d2540;
  --text2: #6b5f8a;
  --text3: #9b8fba;
  --accent: #7c5cbf;
  --accent2: #a67dd4;
  --accent3: #c9b3f0;
  --green: #5bb584;
  --red: #e07070;
  --yellow: #f0c060;
  --shadow: 0 8px 32px rgba(124,92,191,0.12);
  --shadow2: 0 2px 12px rgba(124,92,191,0.08);
  --radius: 20px;
  --night-bg: #0d0b14;
  --night-bg2: #130f1e;
  --night-surface: rgba(30,22,50,0.9);
  --night-text: #e8e0f8;
  --night-accent: #9b7de8;
}
.dark {
  --bg: #0d0b14; --bg2: #130f1e;
  --surface: rgba(25,18,45,0.9); --surface2: rgba(20,14,38,0.8);
  --border: rgba(155,125,232,0.15);
  --text: #e8e0f8; --text2: #b09dd8; --text3: #7a6aaa;
  --accent: #9b7de8; --accent2: #c9a8ff; --accent3: #4a3575;
  --shadow: 0 8px 32px rgba(0,0,0,0.4); --shadow2: 0 2px 12px rgba(0,0,0,0.3);
}

* { box-sizing: border-box; margin: 0; padding: 0; }
body { font-family: 'DM Sans', sans-serif; background: var(--bg); color: var(--text); transition: background 0.4s, color 0.4s; }
h1,h2,h3 { font-family: 'Playfair Display', serif; }

.app { min-height: 100vh; display: flex; flex-direction: column; }

/* Auth */
.auth-screen {
  min-height: 100vh; display: flex; align-items: center; justify-content: center;
  background: linear-gradient(135deg, #1a0e2e 0%, #2d1b54 40%, #0f1a30 100%);
  position: relative; overflow: hidden;
}
.auth-orb {
  position: absolute; border-radius: 50%; filter: blur(80px); opacity: 0.3; pointer-events: none;
}
.auth-card {
  background: rgba(255,255,255,0.05); backdrop-filter: blur(20px);
  border: 1px solid rgba(255,255,255,0.1); border-radius: 28px;
  padding: 48px 40px; width: 420px; max-width: 95vw;
  box-shadow: 0 24px 80px rgba(0,0,0,0.5);
}
.auth-logo { text-align: center; margin-bottom: 32px; }
.auth-logo h1 { color: #e8e0f8; font-size: 2rem; }
.auth-logo p { color: #b09dd8; font-size: 0.9rem; margin-top: 6px; }
.auth-tabs { display: flex; gap: 4px; background: rgba(255,255,255,0.05); border-radius: 12px; padding: 4px; margin-bottom: 28px; }
.auth-tab { flex: 1; padding: 10px; text-align: center; border-radius: 9px; cursor: pointer; font-size: 0.9rem; font-weight: 500; color: #b09dd8; transition: all 0.2s; border: none; background: none; }
.auth-tab.active { background: rgba(155,125,232,0.3); color: #e8e0f8; }
.auth-input {
  width: 100%; padding: 14px 16px; border-radius: 12px;
  background: rgba(255,255,255,0.07); border: 1px solid rgba(255,255,255,0.12);
  color: #e8e0f8; font-size: 0.95rem; font-family: 'DM Sans', sans-serif;
  margin-bottom: 14px; outline: none; transition: border 0.2s;
}
.auth-input:focus { border-color: rgba(155,125,232,0.5); }
.auth-input::placeholder { color: #7a6aaa; }
.btn-primary {
  width: 100%; padding: 14px; border-radius: 12px; border: none; cursor: pointer;
  background: linear-gradient(135deg, #7c5cbf, #9b7de8); color: #fff;
  font-size: 0.95rem; font-weight: 600; font-family: 'DM Sans', sans-serif;
  transition: opacity 0.2s, transform 0.1s; margin-bottom: 12px;
}
.btn-primary:hover { opacity: 0.9; transform: translateY(-1px); }
.btn-google {
  width: 100%; padding: 13px; border-radius: 12px;
  background: rgba(255,255,255,0.08); border: 1px solid rgba(255,255,255,0.15);
  color: #e8e0f8; font-size: 0.9rem; font-weight: 500; font-family: 'DM Sans', sans-serif;
  cursor: pointer; display: flex; align-items: center; justify-content: center; gap: 10px;
  transition: background 0.2s;
}
.btn-google:hover { background: rgba(255,255,255,0.13); }
.auth-divider { text-align: center; color: #7a6aaa; font-size: 0.8rem; margin: 12px 0; }
.auth-error { color: #e07070; font-size: 0.85rem; margin-bottom: 12px; text-align: center; }

/* Nav */
.nav {
  position: sticky; top: 0; z-index: 100;
  background: var(--surface); backdrop-filter: blur(20px);
  border-bottom: 1px solid var(--border);
  padding: 0 24px; height: 64px;
  display: flex; align-items: center; justify-content: space-between;
  box-shadow: var(--shadow2);
}
.nav-brand { display: flex; align-items: center; gap: 10px; }
.nav-brand h1 { font-size: 1.2rem; color: var(--accent); }
.nav-brand span { font-size: 0.75rem; color: var(--text3); display: none; }
.nav-right { display: flex; align-items: center; gap: 12px; }
.nav-avatar {
  width: 36px; height: 36px; border-radius: 50%;
  background: linear-gradient(135deg, var(--accent), var(--accent2));
  display: flex; align-items: center; justify-content: center;
  color: #fff; font-weight: 600; font-size: 0.85rem; cursor: pointer;
  overflow: hidden;
}
.nav-avatar img { width: 100%; height: 100%; object-fit: cover; }
.nav-name { font-size: 0.85rem; color: var(--text2); font-weight: 500; }
.icon-btn {
  width: 36px; height: 36px; border-radius: 10px; border: none; cursor: pointer;
  background: var(--surface2); color: var(--text2); display: flex; align-items: center; justify-content: center;
  transition: all 0.2s;
}
.icon-btn:hover { background: var(--accent3); color: var(--accent); }

/* Sidebar */
.layout { display: flex; flex: 1; }
.sidebar {
  width: 220px; min-height: calc(100vh - 64px); position: sticky; top: 64px;
  background: var(--surface); border-right: 1px solid var(--border);
  padding: 20px 12px; display: flex; flex-direction: column; gap: 4px;
  transition: width 0.3s;
}
.sidebar-item {
  display: flex; align-items: center; gap: 10px; padding: 11px 14px;
  border-radius: 12px; cursor: pointer; color: var(--text2); font-size: 0.88rem; font-weight: 500;
  transition: all 0.2s; border: none; background: none; width: 100%; text-align: left;
}
.sidebar-item:hover { background: var(--bg2); color: var(--accent); }
.sidebar-item.active { background: linear-gradient(135deg, rgba(124,92,191,0.15), rgba(166,125,212,0.1)); color: var(--accent); font-weight: 600; }
.sidebar-item .badge {
  margin-left: auto; background: var(--accent); color: #fff;
  font-size: 0.65rem; padding: 2px 7px; border-radius: 20px;
}
.main { flex: 1; padding: 28px 32px; overflow-y: auto; }

/* Cards */
.card {
  background: var(--surface); border: 1px solid var(--border);
  border-radius: var(--radius); padding: 24px; box-shadow: var(--shadow2);
  transition: box-shadow 0.2s;
}
.card:hover { box-shadow: var(--shadow); }
.card-title { font-size: 1.15rem; font-weight: 600; color: var(--text); margin-bottom: 4px; }
.card-sub { font-size: 0.83rem; color: var(--text3); }

/* Dashboard grid */
.dash-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(260px, 1fr)); gap: 20px; }
.feature-card {
  background: var(--surface); border: 1px solid var(--border);
  border-radius: var(--radius); padding: 22px; cursor: pointer;
  transition: all 0.25s; display: flex; flex-direction: column; gap: 12px;
}
.feature-card:hover { transform: translateY(-3px); box-shadow: var(--shadow); border-color: var(--accent3); }
.feature-icon {
  width: 48px; height: 48px; border-radius: 14px; display: flex; align-items: center; justify-content: center;
  font-size: 1.4rem;
}
.feature-card h3 { font-size: 1rem; font-weight: 600; color: var(--text); }
.feature-card p { font-size: 0.82rem; color: var(--text3); line-height: 1.5; }

/* Chat */
.chat-wrap { display: flex; flex-direction: column; height: calc(100vh - 140px); max-height: 700px; }
.chat-messages {
  flex: 1; overflow-y: auto; padding: 16px; display: flex; flex-direction: column; gap: 14px;
  scrollbar-width: thin; scrollbar-color: var(--border) transparent;
}
.msg { max-width: 75%; display: flex; flex-direction: column; gap: 4px; }
.msg.user { align-self: flex-end; align-items: flex-end; }
.msg.ai { align-self: flex-start; align-items: flex-start; }
.msg-bubble {
  padding: 12px 16px; border-radius: 18px; font-size: 0.9rem; line-height: 1.55;
}
.msg.user .msg-bubble { background: linear-gradient(135deg, var(--accent), var(--accent2)); color: #fff; border-bottom-right-radius: 4px; }
.msg.ai .msg-bubble { background: var(--surface2); color: var(--text); border: 1px solid var(--border); border-bottom-left-radius: 4px; }
.msg-time { font-size: 0.72rem; color: var(--text3); }
.chat-input-row {
  display: flex; gap: 10px; padding: 12px 16px;
  background: var(--surface); border-top: 1px solid var(--border);
  border-radius: 0 0 var(--radius) var(--radius);
}
.chat-input {
  flex: 1; padding: 12px 16px; border-radius: 12px;
  background: var(--bg2); border: 1px solid var(--border);
  color: var(--text); font-size: 0.9rem; font-family: 'DM Sans', sans-serif;
  outline: none; transition: border 0.2s; resize: none;
}
.chat-input:focus { border-color: var(--accent3); }
.chat-send {
  width: 44px; height: 44px; border-radius: 12px; border: none; cursor: pointer;
  background: linear-gradient(135deg, var(--accent), var(--accent2));
  color: #fff; display: flex; align-items: center; justify-content: center;
  transition: opacity 0.2s;
}
.chat-send:disabled { opacity: 0.5; cursor: not-allowed; }
.typing { display: flex; gap: 5px; align-items: center; padding: 10px 14px; }
.dot { width: 7px; height: 7px; border-radius: 50%; background: var(--accent3); animation: bounce 1.2s infinite; }
.dot:nth-child(2) { animation-delay: 0.2s; }
.dot:nth-child(3) { animation-delay: 0.4s; }
@keyframes bounce { 0%,60%,100%{transform:translateY(0)} 30%{transform:translateY(-8px)} }

/* 3AM Mode */
.night-screen {
  min-height: 100vh; background: radial-gradient(ellipse at 50% 30%, #1a0a2e 0%, #0a0612 60%, #020308 100%);
  display: flex; flex-direction: column; align-items: center; justify-content: center;
  position: relative; overflow: hidden; padding: 40px 20px;
}
.stars { position: absolute; inset: 0; pointer-events: none; }
.star-dot { position: absolute; border-radius: 50%; background: white; animation: twinkle 3s infinite; }
@keyframes twinkle { 0%,100%{opacity:0.2} 50%{opacity:0.9} }
.breathe-circle {
  width: 160px; height: 160px; border-radius: 50%;
  background: radial-gradient(circle, rgba(155,125,232,0.4) 0%, rgba(100,60,180,0.1) 70%, transparent 100%);
  display: flex; align-items: center; justify-content: center; flex-direction: column;
  animation: breathe 6s ease-in-out infinite; position: relative;
  border: 1px solid rgba(155,125,232,0.3);
  box-shadow: 0 0 60px rgba(100,60,180,0.3), inset 0 0 30px rgba(155,125,232,0.1);
  cursor: pointer;
}
@keyframes breathe {
  0%,100% { transform: scale(1); box-shadow: 0 0 40px rgba(100,60,180,0.3); }
  50% { transform: scale(1.15); box-shadow: 0 0 80px rgba(100,60,180,0.5), 0 0 120px rgba(155,125,232,0.2); }
}
.breathe-text { color: #c9b3f0; font-size: 0.85rem; margin-top: 8px; }
.night-title { font-family: 'Playfair Display', serif; font-size: 2.2rem; color: #e8e0f8; text-align: center; margin: 32px 0 8px; }
.night-sub { color: #9b8fba; font-size: 0.95rem; text-align: center; margin-bottom: 32px; }
.night-chat { width: 100%; max-width: 560px; }
.night-chat .card { background: rgba(20,12,40,0.8); border-color: rgba(155,125,232,0.2); }
.night-exit {
  margin-top: 24px; padding: 10px 24px; border-radius: 20px;
  background: rgba(155,125,232,0.1); border: 1px solid rgba(155,125,232,0.2);
  color: #9b8fba; cursor: pointer; font-family: 'DM Sans', sans-serif; font-size: 0.85rem;
  transition: all 0.2s;
}
.night-exit:hover { background: rgba(155,125,232,0.2); color: #c9b3f0; }

/* Mood Tracker */
.mood-grid { display: grid; grid-template-columns: repeat(5, 1fr); gap: 12px; margin: 16px 0; }
.mood-btn {
  aspect-ratio: 1; border-radius: 16px; border: 2px solid var(--border);
  background: var(--surface2); cursor: pointer; display: flex; flex-direction: column;
  align-items: center; justify-content: center; gap: 6px; font-size: 1.6rem;
  transition: all 0.2s;
}
.mood-btn:hover, .mood-btn.selected { border-color: var(--accent); background: rgba(124,92,191,0.1); transform: scale(1.06); }
.mood-btn span { font-size: 0.7rem; color: var(--text3); font-weight: 500; }
.mood-chart { display: flex; align-items: flex-end; gap: 6px; height: 80px; padding: 8px 0; }
.mood-bar { flex: 1; border-radius: 6px 6px 0 0; transition: height 0.5s ease; min-height: 4px; }
.journal-input {
  width: 100%; min-height: 100px; padding: 14px; border-radius: 14px;
  background: var(--bg2); border: 1px solid var(--border);
  color: var(--text); font-size: 0.9rem; font-family: 'DM Sans', sans-serif;
  outline: none; resize: vertical; transition: border 0.2s; line-height: 1.6;
}
.journal-input:focus { border-color: var(--accent3); }
.journal-prompt {
  background: linear-gradient(135deg, rgba(124,92,191,0.08), rgba(166,125,212,0.05));
  border: 1px solid var(--accent3); border-radius: 12px; padding: 12px 16px;
  font-size: 0.85rem; color: var(--text2); margin-bottom: 14px; font-style: italic;
}

/* Coping Toolkit */
.breathing-guide {
  width: 140px; height: 140px; border-radius: 50%; margin: 0 auto;
  display: flex; align-items: center; justify-content: center;
  transition: all 1s ease;
  font-size: 0.85rem; font-weight: 600; text-align: center;
}
.step-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(160px, 1fr)); gap: 12px; }
.step-card {
  background: var(--surface2); border: 1px solid var(--border);
  border-radius: 14px; padding: 16px; text-align: center;
  display: flex; flex-direction: column; gap: 8px;
  transition: all 0.2s;
}
.step-card.active { background: rgba(124,92,191,0.1); border-color: var(--accent); }
.step-number { font-size: 1.5rem; font-weight: 700; color: var(--accent); font-family: 'Playfair Display', serif; }

/* Therapist */
.therapist-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 16px; }
.therapist-card {
  background: var(--surface2); border: 1px solid var(--border);
  border-radius: 16px; padding: 20px; text-align: center;
  display: flex; flex-direction: column; align-items: center; gap: 12px;
}
.therapist-avatar {
  width: 64px; height: 64px; border-radius: 50%;
  display: flex; align-items: center; justify-content: center;
  font-size: 1.8rem;
  background: linear-gradient(135deg, var(--accent3), var(--accent2));
}
.badge-green { background: rgba(91,181,132,0.15); color: var(--green); font-size: 0.72rem; padding: 3px 10px; border-radius: 20px; font-weight: 600; }
.badge-purple { background: rgba(124,92,191,0.15); color: var(--accent); font-size: 0.72rem; padding: 3px 10px; border-radius: 20px; font-weight: 600; }

/* Mode toggle */
.mode-pills { display: flex; gap: 8px; flex-wrap: wrap; }
.mode-pill {
  padding: 9px 18px; border-radius: 20px; border: 2px solid var(--border);
  background: var(--surface2); cursor: pointer; font-size: 0.85rem; font-weight: 600;
  color: var(--text2); transition: all 0.2s; font-family: 'DM Sans', sans-serif;
}
.mode-pill:hover { border-color: var(--accent3); color: var(--accent); }
.mode-pill.active { background: linear-gradient(135deg, var(--accent), var(--accent2)); color: #fff; border-color: transparent; }

/* Misc */
.section-header { display: flex; align-items: center; justify-content: space-between; margin-bottom: 20px; }
.section-title { font-size: 1.35rem; font-family: 'Playfair Display', serif; color: var(--text); }
.tag { display: inline-block; padding: 4px 12px; border-radius: 20px; font-size: 0.75rem; font-weight: 600; background: var(--accent3); color: var(--accent); }
.tag-green { background: rgba(91,181,132,0.15); color: var(--green); }
.divider { height: 1px; background: var(--border); margin: 20px 0; }
.row { display: flex; gap: 12px; align-items: center; flex-wrap: wrap; }
.col { display: flex; flex-direction: column; gap: 8px; }
.grid2 { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; }
.mt8 { margin-top: 8px; }
.mt16 { margin-top: 16px; }
.mt24 { margin-top: 24px; }
.mb8 { margin-bottom: 8px; }
.mb16 { margin-bottom: 16px; }
.flex1 { flex: 1; }
.text-sm { font-size: 0.85rem; }
.text-xs { font-size: 0.75rem; }
.text-muted { color: var(--text3); }
.text-accent { color: var(--accent); }
.font-bold { font-weight: 700; }
.center { text-align: center; }
.btn-outline {
  padding: 9px 20px; border-radius: 12px; border: 1.5px solid var(--accent);
  background: transparent; color: var(--accent); cursor: pointer; font-size: 0.85rem;
  font-weight: 600; font-family: 'DM Sans', sans-serif; transition: all 0.2s;
}
.btn-outline:hover { background: rgba(124,92,191,0.1); }
.btn-sm {
  padding: 8px 16px; border-radius: 10px; border: none; cursor: pointer;
  background: linear-gradient(135deg, var(--accent), var(--accent2));
  color: #fff; font-size: 0.82rem; font-weight: 600;
  font-family: 'DM Sans', sans-serif; transition: opacity 0.2s;
}
.btn-sm:hover { opacity: 0.85; }
.btn-danger { background: linear-gradient(135deg, #c04040, #e07070); }
.progress-bar { height: 6px; border-radius: 3px; background: var(--bg2); overflow: hidden; }
.progress-fill { height: 100%; border-radius: 3px; background: linear-gradient(90deg, var(--accent), var(--accent2)); transition: width 0.5s; }
.ai-suggest {
  background: linear-gradient(135deg, rgba(124,92,191,0.08), rgba(166,125,212,0.05));
  border: 1px solid var(--accent3); border-radius: 14px; padding: 16px;
  font-size: 0.88rem; color: var(--text2); line-height: 1.6;
}
.ai-suggest strong { color: var(--accent); }
.pulse { animation: pulse 2s infinite; }
@keyframes pulse { 0%,100%{opacity:1} 50%{opacity:0.6} }
.glow { box-shadow: 0 0 20px rgba(124,92,191,0.3); }
.chip {
  display: inline-flex; align-items: center; gap: 6px; padding: 6px 14px;
  border-radius: 20px; background: var(--surface2); border: 1px solid var(--border);
  font-size: 0.8rem; color: var(--text2); cursor: pointer; transition: all 0.2s;
}
.chip:hover { border-color: var(--accent); color: var(--accent); }
.chip.selected { background: rgba(124,92,191,0.15); border-color: var(--accent); color: var(--accent); }

@media (max-width: 768px) {
  .sidebar { display: none; }
  .main { padding: 16px; }
  .auth-card { padding: 32px 24px; }
  .nav-name { display: none; }
  .grid2 { grid-template-columns: 1fr; }
  .dash-grid { grid-template-columns: 1fr; }
}
`;

// ── Helpers ───────────────────────────────────────────────────────────────────
const now = () =>
  new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });

const MOODS = [
  { emoji: "😄", label: "Great", value: 5, color: "#5bb584" },
  { emoji: "🙂", label: "Good", value: 4, color: "#7bc4a0" },
  { emoji: "😐", label: "Okay", value: 3, color: "#f0c060" },
  { emoji: "😔", label: "Low", value: 2, color: "#e09060" },
  { emoji: "😢", label: "Sad", value: 1, color: "#e07070" },
];

const JOURNAL_PROMPTS = [
  "What small thing made you smile today?",
  "Describe a moment when you felt truly at peace recently.",
  "What's one thing you're grateful for right now?",
  "What would you tell your past self from one year ago?",
  "What emotions are you carrying right now, and where do you feel them in your body?",
  "What's one boundary you'd like to set for yourself this week?",
  "Write about a challenge that actually helped you grow.",
];

const THERAPISTS = [
  { name: "Dr. Priya Sharma", spec: "Anxiety & Trauma", emoji: "👩‍⚕️", avail: "Today 4PM", rating: 4.9 },
  { name: "Dr. Arjun Mehta", spec: "CBT & Depression", emoji: "👨‍⚕️", avail: "Tomorrow 10AM", rating: 4.8 },
  { name: "Dr. Kavya Nair", spec: "Mindfulness & Stress", emoji: "🧑‍⚕️", avail: "Today 7PM", rating: 4.9 },
  { name: "Dr. Rohan Verma", spec: "Relationships & Grief", emoji: "👨‍⚕️", avail: "Tomorrow 2PM", rating: 4.7 },
];

const GROUNDING = [
  { n: 5, sense: "THINGS YOU CAN SEE", icon: "👁️" },
  { n: 4, sense: "THINGS YOU CAN TOUCH", icon: "✋" },
  { n: 3, sense: "THINGS YOU CAN HEAR", icon: "👂" },
  { n: 2, sense: "THINGS YOU CAN SMELL", icon: "👃" },
  { n: 1, sense: "THING YOU CAN TASTE", icon: "👅" },
];

// ── Components ────────────────────────────────────────────────────────────────

function StarField() {
  const stars = Array.from({ length: 60 }, (_, i) => ({
    id: i,
    x: Math.random() * 100,
    y: Math.random() * 100,
    size: Math.random() * 2.5 + 0.5,
    delay: Math.random() * 4,
  }));
  return (
    <div className="stars">
      {stars.map((s) => (
        <div
          key={s.id}
          className="star-dot"
          style={{
            left: `${s.x}%`,
            top: `${s.y}%`,
            width: s.size,
            height: s.size,
            animationDelay: `${s.delay}s`,
          }}
        />
      ))}
    </div>
  );
}

function ChatUI({ system, nightMode = false, welcomeMsg }) {
  const [messages, setMessages] = useState([
    { role: "ai", text: welcomeMsg || "Hi there 💜 I'm your MindSync companion. How are you feeling right now?", time: now() },
  ]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [mode, setMode] = useState("Friend");
  const bottomRef = useRef(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, loading]);

  const send = useCallback(async () => {
    if (!input.trim() || loading) return;
    const userMsg = { role: "user", text: input, time: now() };
    const history = [...messages, userMsg];
    setMessages(history);
    setInput("");
    setLoading(true);
    try {
      const apiMsgs = history
        .filter((m) => m.role !== "ai" || m !== history[0])
        .map((m) => ({ role: m.role === "ai" ? "assistant" : "user", content: m.text }));
      const modeNote = `\n\nCurrent mode: ${mode} Mode. Adjust your tone accordingly (Friend=casual warm, Therapist=professional empathetic, Motivator=energizing uplifting).`;
      const reply = await callAI(apiMsgs, (system || COMPANION_SYSTEM) + modeNote);
      setMessages((prev) => [...prev, { role: "ai", text: reply, time: now() }]);
    } catch {
      setMessages((prev) => [...prev, { role: "ai", text: "I'm right here with you ❤️ (Connection issue — please try again)", time: now() }]);
    }
    setLoading(false);
  }, [input, loading, messages, mode, system]);

  return (
    <div className="chat-wrap">
      {!nightMode && (
        <div style={{ padding: "10px 16px", borderBottom: "1px solid var(--border)", display: "flex", gap: 8, alignItems: "center", flexWrap: "wrap" }}>
          <span className="text-xs text-muted">Mode:</span>
          {["Friend", "Therapist", "Motivator"].map((m) => (
            <button key={m} className={`mode-pill ${mode === m ? "active" : ""}`} style={{ padding: "5px 14px", fontSize: "0.78rem" }} onClick={() => setMode(m)}>
              {m === "Friend" ? "🤝" : m === "Therapist" ? "🩺" : "⚡"} {m}
            </button>
          ))}
        </div>
      )}
      <div className="chat-messages">
        {messages.map((m, i) => (
          <div key={i} className={`msg ${m.role === "user" ? "user" : "ai"}`}>
            <div className="msg-bubble" style={{ whiteSpace: "pre-wrap" }}>{m.text}</div>
            <span className="msg-time">{m.time}</span>
          </div>
        ))}
        {loading && (
          <div className="msg ai">
            <div className="msg-bubble">
              <div className="typing">
                <div className="dot" /><div className="dot" /><div className="dot" />
              </div>
            </div>
          </div>
        )}
        <div ref={bottomRef} />
      </div>
      <div className="chat-input-row">
        <textarea
          className="chat-input"
          rows={1}
          placeholder="Share how you're feeling…"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); send(); } }}
          style={{ height: 44, maxHeight: 120 }}
        />
        <button className="chat-send" onClick={send} disabled={loading || !input.trim()}>
          <Icon d={icons.send} size={16} />
        </button>
      </div>
    </div>
  );
}

// ── Pages ─────────────────────────────────────────────────────────────────────

function NightMode({ onExit }) {
  return (
    <div className="night-screen">
      <StarField />
      <div className="breathe-circle">
        <span style={{ fontSize: "2rem" }}>🌙</span>
        <span className="breathe-text">Breathe with me</span>
      </div>
      <h1 className="night-title">You're not alone at 3 AM</h1>
      <p className="night-sub">Someone is always here — no matter the hour 💜</p>
      <div className="night-chat" style={{ width: "100%", maxWidth: 560 }}>
        <div className="card" style={{ padding: 0, overflow: "hidden", background: "rgba(15,9,28,0.85)", borderColor: "rgba(155,125,232,0.15)" }}>
          <ChatUI
            nightMode
            welcomeMsg="Hey, I'm so glad you're here 🌙 It's okay that it's late — I'm not going anywhere. What's on your mind?"
          />
        </div>
      </div>
      <button className="night-exit" onClick={onExit}>← Return to daylight</button>
    </div>
  );
}

function MoodTracker() {
  const [selectedMood, setSelectedMood] = useState(null);
  const [journal, setJournal] = useState("");
  const [saved, setSaved] = useState(false);
  const [aiInsight, setAiInsight] = useState("");
  const [loadingInsight, setLoadingInsight] = useState(false);
  const promptIdx = new Date().getDate() % JOURNAL_PROMPTS.length;
  const prompt = JOURNAL_PROMPTS[promptIdx];

  const mockHistory = [3, 4, 4, 2, 3, 5, 4];
  const days = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];

  const getInsight = async () => {
    if (!selectedMood || !journal.trim()) return;
    setLoadingInsight(true);
    try {
      const reply = await callAI(
        [{ role: "user", content: `My mood today: ${selectedMood.label} (${selectedMood.value}/5). Journal: "${journal}". Give me a 2-3 sentence warm, empathetic AI insight about my emotional patterns and one actionable suggestion. Be brief and caring.` }],
        "You are a gentle AI wellness companion. Provide warm, brief emotional insights."
      );
      setAiInsight(reply);
    } catch {
      setAiInsight("Keep going — every entry is a step toward understanding yourself better 💜");
    }
    setLoadingInsight(false);
  };

  return (
    <div>
      <div className="section-header">
        <h2 className="section-title">Mood Tracker & Journal</h2>
        <span className="tag">📊 Daily Check-in</span>
      </div>

      <div className="grid2">
        <div className="card">
          <div className="card-title mb8">How are you feeling today?</div>
          <div className="mood-grid" style={{ gridTemplateColumns: "repeat(5,1fr)" }}>
            {MOODS.map((m) => (
              <button key={m.value} className={`mood-btn ${selectedMood?.value === m.value ? "selected" : ""}`} onClick={() => setSelectedMood(m)}>
                <span>{m.emoji}</span>
                <span>{m.label}</span>
              </button>
            ))}
          </div>
          {selectedMood && (
            <div style={{ marginTop: 12, padding: "10px 14px", borderRadius: 12, background: "rgba(124,92,191,0.08)", borderLeft: `3px solid ${selectedMood.color}` }}>
              <span className="text-sm" style={{ color: selectedMood.color }}>You're feeling {selectedMood.label} today {selectedMood.emoji}</span>
            </div>
          )}
        </div>

        <div className="card">
          <div className="card-title mb8">This Week's Mood</div>
          <div className="mood-chart">
            {mockHistory.map((v, i) => (
              <div key={i} style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", gap: 4 }}>
                <div className="mood-bar" style={{ width: "100%", height: `${v * 15}px`, background: MOODS[5 - v]?.color || "#9b7de8" }} />
                <span className="text-xs text-muted">{days[i]}</span>
              </div>
            ))}
          </div>
          <div className="mt8">
            <div className="text-xs text-muted mb8">Average this week</div>
            <div className="progress-bar">
              <div className="progress-fill" style={{ width: "72%" }} />
            </div>
            <div className="text-xs text-accent mt8">3.6 / 5 — You're doing well 💜</div>
          </div>
        </div>
      </div>

      <div className="card mt16">
        <div className="card-title mb8">✍️ Today's Journal</div>
        <div className="journal-prompt">💭 Prompt: "{prompt}"</div>
        <textarea
          className="journal-input"
          placeholder="Write freely — this is your safe space…"
          value={journal}
          onChange={(e) => setJournal(e.target.value)}
        />
        <div className="row mt8">
          <button className="btn-sm" onClick={() => { setSaved(true); setTimeout(() => setSaved(false), 2000); getInsight(); }}>
            {saved ? "✓ Saved!" : "Save Entry"}
          </button>
          <button className="btn-outline" onClick={getInsight} style={{ fontSize: "0.82rem" }}>
            ✨ Get AI Insight
          </button>
        </div>
        {loadingInsight && <div className="ai-suggest mt16 pulse">Analyzing your entry… ✨</div>}
        {aiInsight && !loadingInsight && (
          <div className="ai-suggest mt16">
            <strong>💜 AI Insight:</strong><br />{aiInsight}
          </div>
        )}
      </div>
    </div>
  );
}

function CopingToolkit() {
  const [breathPhase, setBreathPhase] = useState("idle");
  const [breathCount, setBreathCount] = useState(0);
  const [activeGround, setActiveGround] = useState(null);
  const [groundStep, setGroundStep] = useState(0);
  const timerRef = useRef(null);

  const PHASES = [
    { name: "Inhale", duration: 4000, color: "#7c5cbf", scale: 1.3 },
    { name: "Hold", duration: 4000, color: "#a67dd4", scale: 1.3 },
    { name: "Exhale", duration: 6000, color: "#5bb584", scale: 1 },
    { name: "Hold", duration: 2000, color: "#9b8fba", scale: 1 },
  ];
  const [phaseIdx, setPhaseIdx] = useState(0);

  const startBreath = () => {
    setBreathPhase("running");
    setPhaseIdx(0);
    setBreathCount(0);
  };
  const stopBreath = () => {
    setBreathPhase("idle");
    clearTimeout(timerRef.current);
  };

  useEffect(() => {
    if (breathPhase !== "running") return;
    const phase = PHASES[phaseIdx];
    timerRef.current = setTimeout(() => {
      const next = (phaseIdx + 1) % PHASES.length;
      setPhaseIdx(next);
      if (next === 0) setBreathCount((c) => c + 1);
    }, phase.duration);
    return () => clearTimeout(timerRef.current);
  }, [breathPhase, phaseIdx]);

  const currentPhase = PHASES[phaseIdx];

  return (
    <div>
      <div className="section-header">
        <h2 className="section-title">Smart Coping Toolkit</h2>
        <span className="tag">🧘 Instant Relief</span>
      </div>

      <div className="grid2">
        <div className="card" style={{ textAlign: "center" }}>
          <div className="card-title mb8">Box Breathing</div>
          <div className="card-sub mb16">4-4-6-2 technique for instant calm</div>
          <div
            className="breathing-guide"
            style={{
              background: `radial-gradient(circle, ${breathPhase === "running" ? currentPhase.color + "55" : "var(--surface2)"} 0%, transparent 80%)`,
              border: `3px solid ${breathPhase === "running" ? currentPhase.color : "var(--border)"}`,
              transform: breathPhase === "running" ? `scale(${currentPhase.scale})` : "scale(1)",
              color: breathPhase === "running" ? currentPhase.color : "var(--text3)",
              boxShadow: breathPhase === "running" ? `0 0 40px ${currentPhase.color}44` : "none",
            }}
          >
            <div style={{ fontSize: "1.1rem", fontWeight: 700 }}>
              {breathPhase === "running" ? currentPhase.name : "Ready"}
            </div>
            {breathPhase === "running" && <div className="text-xs mt8">{breathCount} cycles</div>}
          </div>
          <div className="row mt16" style={{ justifyContent: "center" }}>
            {breathPhase === "idle" ? (
              <button className="btn-sm" onClick={startBreath}>▶ Start</button>
            ) : (
              <button className="btn-sm btn-danger" onClick={stopBreath}>■ Stop</button>
            )}
          </div>
        </div>

        <div className="card">
          <div className="card-title mb8">5-4-3-2-1 Grounding</div>
          <div className="card-sub mb16">Anchor yourself to the present moment</div>
          {GROUNDING.map((g, i) => (
            <div
              key={i}
              className={`step-card mt8 ${activeGround === i ? "active" : ""}`}
              style={{ flexDirection: "row", padding: "12px 14px", cursor: "pointer" }}
              onClick={() => setActiveGround(activeGround === i ? null : i)}
            >
              <span className="step-number" style={{ fontSize: "1.1rem", minWidth: 28 }}>{g.n}</span>
              <span style={{ fontSize: "0.8rem", color: activeGround === i ? "var(--accent)" : "var(--text2)" }}>
                {g.icon} {g.sense}
              </span>
            </div>
          ))}
        </div>
      </div>

      <div className="card mt16">
        <div className="card-title mb8">🤖 AI-Powered Suggestion</div>
        <div className="ai-suggest">
          <strong>Based on your recent mood patterns:</strong><br />
          You've been experiencing elevated stress mid-week. Try the <strong>4-7-8 breathing technique</strong> before sleep tonight — it activates your parasympathetic nervous system and can reduce anxiety by up to 60%. Also, a 10-minute evening walk might break the pattern. 💜
        </div>
        <div className="row mt12">
          <span className="chip selected">🫁 Breathing</span>
          <span className="chip">🚶 Walking</span>
          <span className="chip">📓 Journaling</span>
          <span className="chip">🎵 Music</span>
        </div>
      </div>
    </div>
  );
}

function TherapistSession({ onStartChat }) {
  const [booked, setBooked] = useState(null);
  return (
    <div>
      <div className="section-header">
        <h2 className="section-title">Therapist Sessions</h2>
        <span className="tag tag-green">🩺 Professional Help</span>
      </div>

      <div className="ai-suggest mb16" style={{ display: "flex", alignItems: "center", gap: 12 }}>
        <span style={{ fontSize: "1.5rem" }}>🤖</span>
        <div>
          <strong>AI Notice:</strong> Based on your recent check-ins, you might benefit from speaking with a professional. Would you like to talk to a therapist?
          <div className="row mt8">
            <button className="btn-sm" onClick={() => document.getElementById("therapist-list")?.scrollIntoView({ behavior: "smooth" })}>
              Yes, book a session
            </button>
            <button className="btn-outline" style={{ fontSize: "0.8rem" }} onClick={onStartChat}>
              Talk to AI first
            </button>
          </div>
        </div>
      </div>

      <div className="row mb16">
        {["Chat", "Audio", "Video"].map((t) => (
          <span key={t} className="chip selected" style={{ cursor: "default" }}>
            {t === "Chat" ? "💬" : t === "Audio" ? "📞" : "📹"} {t}
          </span>
        ))}
      </div>

      <div id="therapist-list" className="therapist-grid">
        {THERAPISTS.map((t, i) => (
          <div key={i} className="therapist-card">
            <div className="therapist-avatar">{t.emoji}</div>
            <div>
              <div style={{ fontWeight: 600, fontSize: "0.92rem" }}>{t.name}</div>
              <div className="text-xs text-muted">{t.spec}</div>
            </div>
            <div className="row" style={{ justifyContent: "center", gap: 6 }}>
              <span className="badge-green">⭐ {t.rating}</span>
              <span className="badge-purple">📅 {t.avail}</span>
            </div>
            {booked === i ? (
              <div style={{ color: "var(--green)", fontSize: "0.85rem", fontWeight: 600 }}>✓ Booked!</div>
            ) : (
              <button className="btn-sm" style={{ width: "100%" }} onClick={() => setBooked(i)}>
                Book Now
              </button>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}

function Personalization({ mode, setMode }) {
  const [prefs, setPrefs] = useState({ reminders: true, insights: true, nightMode: false });
  return (
    <div>
      <div className="section-header">
        <h2 className="section-title">Personalization</h2>
        <span className="tag">🎭 Your Space</span>
      </div>
      <div className="card mb16">
        <div className="card-title mb16">Companion Mode</div>
        <div className="mode-pills">
          {[
            { id: "Friend", emoji: "🤝", desc: "Casual, warm, and supportive" },
            { id: "Therapist", emoji: "🩺", desc: "Professional and empathetic" },
            { id: "Motivator", emoji: "⚡", desc: "Energizing and uplifting" },
          ].map((m) => (
            <button key={m.id} className={`mode-pill ${mode === m.id ? "active" : ""}`} onClick={() => setMode(m.id)}>
              {m.emoji} {m.id} Mode
            </button>
          ))}
        </div>
        <div className="ai-suggest mt16">
          <strong>Current: {mode} Mode</strong><br />
          {mode === "Friend" && "I'll be your warm, casual companion — here to listen and support without judgment 💜"}
          {mode === "Therapist" && "I'll guide you with evidence-based techniques and professional empathy 🩺"}
          {mode === "Motivator" && "I'll energize you, celebrate your wins, and push you toward your best self ⚡"}
        </div>
      </div>
      <div className="card">
        <div className="card-title mb16">Preferences</div>
        {[
          { key: "reminders", label: "Daily mood check-in reminders", desc: "Get a gentle nudge every evening" },
          { key: "insights", label: "Weekly AI insights", desc: "Personalized pattern analysis" },
          { key: "nightMode", label: "Auto Night Mode after 10 PM", desc: "Switch to calming dark UI" },
        ].map((p) => (
          <div key={p.key} style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "12px 0", borderBottom: "1px solid var(--border)" }}>
            <div>
              <div style={{ fontSize: "0.9rem", fontWeight: 500 }}>{p.label}</div>
              <div className="text-xs text-muted">{p.desc}</div>
            </div>
            <div
              style={{
                width: 44, height: 24, borderRadius: 12, cursor: "pointer", position: "relative",
                background: prefs[p.key] ? "var(--accent)" : "var(--bg2)",
                transition: "background 0.2s",
              }}
              onClick={() => setPrefs((prev) => ({ ...prev, [p.key]: !prev[p.key] }))}
            >
              <div style={{
                position: "absolute", top: 3, left: prefs[p.key] ? 23 : 3,
                width: 18, height: 18, borderRadius: "50%", background: "#fff",
                transition: "left 0.2s", boxShadow: "0 1px 4px rgba(0,0,0,0.2)"
              }} />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function Dashboard({ setPage }) {
  const features = [
    { id: "night", icon: "🌙", title: "3 AM Companion", desc: "Late-night support with calming presence", color: "#1a0e2e", tag: "Night Mode" },
    { id: "chat", icon: "💬", title: "Emotion-Aware AI", desc: "Voice & text companion that truly understands", color: "#1a0e3e", tag: "AI Chat" },
    { id: "mood", icon: "📊", title: "Mood Tracker", desc: "Daily logging with AI-powered insights", color: "#0e1a2e", tag: "Journal" },
    { id: "coping", icon: "🧘", title: "Coping Toolkit", desc: "Breathing, grounding, and calming exercises", color: "#0e2e1a", tag: "Tools" },
    { id: "therapist", icon: "🩺", title: "Therapist Session", desc: "Connect with certified mental health professionals", color: "#2e1a0e", tag: "Pro Help" },
    { id: "settings", icon: "🎭", title: "Personalization", desc: "Customize your companion's mode and preferences", color: "#1a1a2e", tag: "Settings" },
  ];
  return (
    <div>
      <div className="section-header">
        <div>
          <h2 className="section-title">Welcome back 💜</h2>
          <div className="text-sm text-muted mt8">How are you feeling today? Let's check in.</div>
        </div>
        <span className="tag pulse">● Live Support</span>
      </div>
      <div className="ai-suggest mb24">
        <strong>🤖 Daily Insight:</strong> You've logged your mood 5 days in a row — that's amazing self-awareness! Your mood tends to dip mid-week. Consider a short meditation on Wednesday evenings. 💜
      </div>
      <div className="dash-grid">
        {features.map((f) => (
          <div key={f.id} className="feature-card" onClick={() => setPage(f.id)}>
            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
              <div className="feature-icon" style={{ background: f.color }}>
                <span>{f.icon}</span>
              </div>
              <span className="tag" style={{ fontSize: "0.7rem" }}>{f.tag}</span>
            </div>
            <h3>{f.title}</h3>
            <p>{f.desc}</p>
          </div>
        ))}
      </div>
    </div>
  );
}

// ── Auth Screen ───────────────────────────────────────────────────────────────
function AuthScreen({ onLogin }) {
  const [tab, setTab] = useState("signin");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const handleEmail = async () => {
    setError(""); setLoading(true);
    const fn = tab === "signin" ? supabase.auth.signInWithPassword : supabase.auth.signUp;
    const { data, error: err } = await fn({ email, password });
    setLoading(false);
    if (err) { setError(err.message); return; }
    if (data?.user) onLogin(data.user);
  };

  const handleGoogle = async () => {
    await supabase.auth.signInWithOAuth({ provider: "google" });
    // In demo mode, auto-login
    onLogin({ id: "google-demo", email: "user@gmail.com", user_metadata: { full_name: "Demo User", avatar_url: null } });
  };

  return (
    <div className="auth-screen">
      <div className="auth-orb" style={{ width: 500, height: 500, top: -150, right: -150, background: "radial-gradient(circle, #7c5cbf, transparent)" }} />
      <div className="auth-orb" style={{ width: 400, height: 400, bottom: -100, left: -100, background: "radial-gradient(circle, #3a1a6e, transparent)" }} />
      <div className="auth-card">
        <div className="auth-logo">
          <h1>🧠 MindSync</h1>
          <p>AI Powered Mental Wellness</p>
          <p style={{ color: "#7a6aaa", fontSize: "0.78rem", marginTop: 4 }}>Someone is always here for you 💜</p>
        </div>
        <div className="auth-tabs">
          <button className={`auth-tab ${tab === "signin" ? "active" : ""}`} onClick={() => setTab("signin")}>Sign In</button>
          <button className={`auth-tab ${tab === "signup" ? "active" : ""}`} onClick={() => setTab("signup")}>Sign Up</button>
        </div>
        {error && <div className="auth-error">{error}</div>}
        <input className="auth-input" type="email" placeholder="Email address" value={email} onChange={(e) => setEmail(e.target.value)} />
        <input className="auth-input" type="password" placeholder="Password" value={password} onChange={(e) => setPassword(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && handleEmail()} />
        <button className="btn-primary" onClick={handleEmail} disabled={loading}>
          {loading ? "Please wait…" : tab === "signin" ? "Sign In" : "Create Account"}
        </button>
        <div className="auth-divider">or continue with</div>
        <button className="btn-google" onClick={handleGoogle}>
          <svg width="18" height="18" viewBox="0 0 24 24"><path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/><path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/><path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/><path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/></svg>
          Continue with Google
        </button>
      </div>
    </div>
  );
}

// ── Main App ──────────────────────────────────────────────────────────────────
export default function MindSync() {
  const [user, setUser] = useState(null);
  const [dark, setDark] = useState(IS_NIGHT());
  const [page, setPage] = useState("dashboard");
  const [mode, setMode] = useState("Friend");
  const [nightActive, setNightActive] = useState(false);

  const nav = [
    { id: "dashboard", label: "Home", icon: icons.heart },
    { id: "chat", label: "AI Companion", icon: icons.chat },
    { id: "mood", label: "Mood & Journal", icon: icons.chart },
    { id: "coping", label: "Coping Toolkit", icon: icons.brain },
    { id: "therapist", label: "Therapist", icon: icons.doctor },
    { id: "night", label: "3 AM Mode", icon: icons.moon, badge: IS_NIGHT() ? "Now" : null },
    { id: "settings", label: "Personalize", icon: icons.star },
  ];

  const initials = user
    ? (user.user_metadata?.full_name || user.email || "U").split(" ").map((w) => w[0]).join("").slice(0, 2).toUpperCase()
    : "?";
  const displayName = user?.user_metadata?.full_name || user?.email?.split("@")[0] || "Friend";

  const handleLogout = async () => {
    await supabase.auth.signOut();
    setUser(null);
  };

  if (!user) return (
    <>
      <style>{CSS}</style>
      <AuthScreen onLogin={setUser} />
    </>
  );

  if (nightActive || page === "night") return (
    <>
      <style>{CSS}</style>
      <NightMode onExit={() => { setNightActive(false); setPage("dashboard"); }} />
    </>
  );

  return (
    <>
      <style>{CSS}</style>
      <div className={`app ${dark ? "dark" : ""}`}>
        {/* Nav */}
        <nav className="nav">
          <div className="nav-brand">
            <span style={{ fontSize: "1.3rem" }}>🧠</span>
            <h1>MindSync</h1>
          </div>
          <div className="nav-right">
            {IS_NIGHT() && (
              <button className="icon-btn" title="Activate 3AM Mode" onClick={() => setNightActive(true)} style={{ color: "var(--accent2)" }}>
                <Icon d={icons.moon} size={17} />
              </button>
            )}
            <button className="icon-btn" onClick={() => setDark((d) => !d)} title="Toggle theme">
              <Icon d={dark ? icons.sun : icons.moon} size={17} />
            </button>
            <span className="nav-name">{displayName}</span>
            <div className="nav-avatar">
              {user?.user_metadata?.avatar_url ? (
                <img src={user.user_metadata.avatar_url} alt={displayName} />
              ) : initials}
            </div>
            <button className="icon-btn" onClick={handleLogout} title="Sign out">
              <Icon d={icons.logout} size={17} />
            </button>
          </div>
        </nav>

        <div className="layout">
          {/* Sidebar */}
          <aside className="sidebar">
            {nav.map((item) => (
              <button key={item.id} className={`sidebar-item ${page === item.id ? "active" : ""}`} onClick={() => setPage(item.id)}>
                <Icon d={item.icon} size={17} />
                {item.label}
                {item.badge && <span className="badge">{item.badge}</span>}
              </button>
            ))}
            <div style={{ flex: 1 }} />
            <button className="sidebar-item" onClick={handleLogout}>
              <Icon d={icons.logout} size={17} />
              Sign Out
            </button>
          </aside>

          {/* Main */}
          <main className="main">
            {page === "dashboard" && <Dashboard setPage={setPage} />}
            {page === "chat" && (
              <div>
                <div className="section-header">
                  <h2 className="section-title">Emotion-Aware AI Companion</h2>
                  <span className="tag">💬 {mode} Mode</span>
                </div>
                <div className="card" style={{ padding: 0, overflow: "hidden" }}>
                  <ChatUI />
                </div>
              </div>
            )}
            {page === "mood" && <MoodTracker />}
            {page === "coping" && <CopingToolkit />}
            {page === "therapist" && <TherapistSession onStartChat={() => setPage("chat")} />}
            {page === "settings" && <Personalization mode={mode} setMode={setMode} />}
          </main>
        </div>
      </div>
    </>
  );
}
