# 🧠 MindSync — AI Powered Mental Wellness

A calming, production-ready mental wellness app built with React + Supabase + Claude AI.

---

## ✨ Features

| Feature | Description |
|---|---|
| 🌙 3 AM Companion | Late-night dark mode with breathing animation + AI chat |
| 💬 Emotion-Aware AI | Claude-powered companion with Friend / Therapist / Motivator modes |
| 📊 Mood Tracker | Daily emoji mood logging + weekly chart + AI journal insights |
| 🧘 Coping Toolkit | Box breathing, 5-4-3-2-1 grounding, AI suggestions |
| 🩺 Therapist Session | Book certified therapists via chat / audio / video |
| 🎭 Personalization | Mode switching, reminders, night-mode auto-trigger |

---

## 🚀 Deploy in One Command

### Prerequisites
- Node.js 18+
- A free [Vercel account](https://vercel.com)
- A free [Supabase project](https://supabase.com)

### Steps

```bash
# 1. Install dependencies
npm install

# 2. Copy env file and fill in your keys
cp .env.example .env

# 3. Run locally
npm start

# 4. Deploy to Vercel (get a live link instantly)
npx vercel
```

That's it! Vercel will give you a `https://mindsync-xxx.vercel.app` link.

---

## 🔧 Supabase Setup

### 1. Create tables

```sql
-- Mood entries
create table mood_logs (
  id uuid default gen_random_uuid() primary key,
  user_id uuid references auth.users,
  mood_value int,
  mood_label text,
  journal text,
  ai_insight text,
  created_at timestamptz default now()
);

-- Chat history
create table chat_messages (
  id uuid default gen_random_uuid() primary key,
  user_id uuid references auth.users,
  role text,
  content text,
  created_at timestamptz default now()
);

-- Therapist bookings
create table bookings (
  id uuid default gen_random_uuid() primary key,
  user_id uuid references auth.users,
  therapist_name text,
  session_type text,
  scheduled_at timestamptz,
  created_at timestamptz default now()
);
```

### 2. Enable Row Level Security

```sql
alter table mood_logs enable row level security;
alter table chat_messages enable row level security;
alter table bookings enable row level security;

-- Users can only see their own data
create policy "own data" on mood_logs for all using (auth.uid() = user_id);
create policy "own data" on chat_messages for all using (auth.uid() = user_id);
create policy "own data" on bookings for all using (auth.uid() = user_id);
```

### 3. Enable Google Auth
Go to **Supabase Dashboard → Authentication → Providers → Google** and add your OAuth credentials.

---

## 🔑 Connect Real Supabase

In `src/App.js`, replace the mock `supabase` object:

```js
import { createClient } from '@supabase/supabase-js'

const supabase = createClient(
  process.env.REACT_APP_SUPABASE_URL,
  process.env.REACT_APP_SUPABASE_ANON_KEY
)
```

Install the client:
```bash
npm install @supabase/supabase-js
```

---

## 🛡️ Production Notes

- **Never expose your Anthropic API key in the frontend.** Use a serverless function (Vercel Edge Function or Supabase Edge Function) to proxy AI calls.
- The demo uses a mock Supabase layer — swap it out before going live.

---

## 💜 Built with care

MindSync is designed to make people feel safe, heard, and supported.
